namespace CSharpMySqlSample
{
    partial class FormMySql
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(FormMySql));
            this.dataGridViewWorck = new System.Windows.Forms.DataGridView();
            this.cmb_Save = new System.Windows.Forms.Button();
            this.cmb_Delete = new System.Windows.Forms.Button();
            this.cmb_Main_Exit = new System.Windows.Forms.Button();
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.dataToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.workToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.manufactoringToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.laveToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.expeditionedToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.tabControl1 = new System.Windows.Forms.TabControl();
            this.tabPage1 = new System.Windows.Forms.TabPage();
            this.tabPage2 = new System.Windows.Forms.TabPage();
            this.lblLinia = new System.Windows.Forms.Label();
            this.lblMold = new System.Windows.Forms.Label();
            this.lblLav = new System.Windows.Forms.Label();
            this.lblAritcle = new System.Windows.Forms.Label();
            this.lblBu = new System.Windows.Forms.Label();
            this.lblData = new System.Windows.Forms.Label();
            this.dateTimePicker = new System.Windows.Forms.DateTimePicker();
            this.label8 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.cmb_Manufatured = new System.Windows.Forms.Button();
            this.lbl_Total = new System.Windows.Forms.Label();
            this.comboBoxLinia = new System.Windows.Forms.ComboBox();
            this.txt_No45 = new System.Windows.Forms.TextBox();
            this.txt_No46 = new System.Windows.Forms.TextBox();
            this.txt_No44 = new System.Windows.Forms.TextBox();
            this.txt_No43 = new System.Windows.Forms.TextBox();
            this.txt_No41 = new System.Windows.Forms.TextBox();
            this.txt_No42 = new System.Windows.Forms.TextBox();
            this.txt_No40 = new System.Windows.Forms.TextBox();
            this.txt_No39 = new System.Windows.Forms.TextBox();
            this.txtFoudoID = new System.Windows.Forms.TextBox();
            this.txt_LavID = new System.Windows.Forms.TextBox();
            this.txt_AtricleID = new System.Windows.Forms.TextBox();
            this.txt_BuID = new System.Windows.Forms.TextBox();
            this.cmb_RunDown = new System.Windows.Forms.Button();
            this.cmb_RunUper = new System.Windows.Forms.Button();
            this.dataGridViewDown = new System.Windows.Forms.DataGridView();
            this.dataGridViewUp = new System.Windows.Forms.DataGridView();
            this.textBox1 = new System.Windows.Forms.TextBox();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewWorck)).BeginInit();
            this.menuStrip1.SuspendLayout();
            this.tabControl1.SuspendLayout();
            this.tabPage1.SuspendLayout();
            this.tabPage2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewDown)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewUp)).BeginInit();
            this.SuspendLayout();
            // 
            // dataGridViewWorck
            // 
            this.dataGridViewWorck.AllowUserToDeleteRows = false;
            this.dataGridViewWorck.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dataGridViewWorck.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            resources.ApplyResources(this.dataGridViewWorck, "dataGridViewWorck");
            this.dataGridViewWorck.Name = "dataGridViewWorck";
            this.dataGridViewWorck.CellBeginEdit += new System.Windows.Forms.DataGridViewCellCancelEventHandler(this.dataGridViewWorck_CellBeginEdit);
            // 
            // cmb_Save
            // 
            resources.ApplyResources(this.cmb_Save, "cmb_Save");
            this.cmb_Save.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(192)))));
            this.cmb_Save.Name = "cmb_Save";
            this.cmb_Save.UseVisualStyleBackColor = true;
            this.cmb_Save.Click += new System.EventHandler(this.btnSave_Click);
            // 
            // cmb_Delete
            // 
            resources.ApplyResources(this.cmb_Delete, "cmb_Delete");
            this.cmb_Delete.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(192)))));
            this.cmb_Delete.Name = "cmb_Delete";
            this.cmb_Delete.UseVisualStyleBackColor = true;
            this.cmb_Delete.Click += new System.EventHandler(this.btnDelete_Click);
            // 
            // cmb_Main_Exit
            // 
            resources.ApplyResources(this.cmb_Main_Exit, "cmb_Main_Exit");
            this.cmb_Main_Exit.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(192)))));
            this.cmb_Main_Exit.Name = "cmb_Main_Exit";
            this.cmb_Main_Exit.UseVisualStyleBackColor = true;
            this.cmb_Main_Exit.Click += new System.EventHandler(this.cmb_Main_Exit_Click);
            // 
            // menuStrip1
            // 
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.dataToolStripMenuItem});
            resources.ApplyResources(this.menuStrip1, "menuStrip1");
            this.menuStrip1.Name = "menuStrip1";
            // 
            // dataToolStripMenuItem
            // 
            this.dataToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.workToolStripMenuItem,
            this.manufactoringToolStripMenuItem,
            this.laveToolStripMenuItem,
            this.expeditionedToolStripMenuItem});
            this.dataToolStripMenuItem.Name = "dataToolStripMenuItem";
            resources.ApplyResources(this.dataToolStripMenuItem, "dataToolStripMenuItem");
            // 
            // workToolStripMenuItem
            // 
            this.workToolStripMenuItem.Name = "workToolStripMenuItem";
            resources.ApplyResources(this.workToolStripMenuItem, "workToolStripMenuItem");
            this.workToolStripMenuItem.Click += new System.EventHandler(this.workToolStripMenuItem_Click);
            // 
            // manufactoringToolStripMenuItem
            // 
            this.manufactoringToolStripMenuItem.Name = "manufactoringToolStripMenuItem";
            resources.ApplyResources(this.manufactoringToolStripMenuItem, "manufactoringToolStripMenuItem");
            this.manufactoringToolStripMenuItem.Click += new System.EventHandler(this.manufactoringToolStripMenuItem_Click);
            // 
            // laveToolStripMenuItem
            // 
            this.laveToolStripMenuItem.Name = "laveToolStripMenuItem";
            resources.ApplyResources(this.laveToolStripMenuItem, "laveToolStripMenuItem");
            // 
            // expeditionedToolStripMenuItem
            // 
            this.expeditionedToolStripMenuItem.Name = "expeditionedToolStripMenuItem";
            resources.ApplyResources(this.expeditionedToolStripMenuItem, "expeditionedToolStripMenuItem");
            // 
            // tabControl1
            // 
            this.tabControl1.Controls.Add(this.tabPage1);
            this.tabControl1.Controls.Add(this.tabPage2);
            resources.ApplyResources(this.tabControl1, "tabControl1");
            this.tabControl1.Name = "tabControl1";
            this.tabControl1.SelectedIndex = 1;
            // 
            // tabPage1
            // 
            this.tabPage1.Controls.Add(this.dataGridViewWorck);
            this.tabPage1.Controls.Add(this.cmb_Main_Exit);
            this.tabPage1.Controls.Add(this.cmb_Save);
            this.tabPage1.Controls.Add(this.cmb_Delete);
            resources.ApplyResources(this.tabPage1, "tabPage1");
            this.tabPage1.Name = "tabPage1";
            this.tabPage1.UseVisualStyleBackColor = true;
            // 
            // tabPage2
            // 
            this.tabPage2.Controls.Add(this.textBox1);
            this.tabPage2.Controls.Add(this.lblLinia);
            this.tabPage2.Controls.Add(this.lblMold);
            this.tabPage2.Controls.Add(this.lblLav);
            this.tabPage2.Controls.Add(this.lblAritcle);
            this.tabPage2.Controls.Add(this.lblBu);
            this.tabPage2.Controls.Add(this.lblData);
            this.tabPage2.Controls.Add(this.dateTimePicker);
            this.tabPage2.Controls.Add(this.label8);
            this.tabPage2.Controls.Add(this.label7);
            this.tabPage2.Controls.Add(this.label6);
            this.tabPage2.Controls.Add(this.label5);
            this.tabPage2.Controls.Add(this.label4);
            this.tabPage2.Controls.Add(this.label3);
            this.tabPage2.Controls.Add(this.label2);
            this.tabPage2.Controls.Add(this.label1);
            this.tabPage2.Controls.Add(this.cmb_Manufatured);
            this.tabPage2.Controls.Add(this.lbl_Total);
            this.tabPage2.Controls.Add(this.comboBoxLinia);
            this.tabPage2.Controls.Add(this.txt_No45);
            this.tabPage2.Controls.Add(this.txt_No46);
            this.tabPage2.Controls.Add(this.txt_No44);
            this.tabPage2.Controls.Add(this.txt_No43);
            this.tabPage2.Controls.Add(this.txt_No41);
            this.tabPage2.Controls.Add(this.txt_No42);
            this.tabPage2.Controls.Add(this.txt_No40);
            this.tabPage2.Controls.Add(this.txt_No39);
            this.tabPage2.Controls.Add(this.txtFoudoID);
            this.tabPage2.Controls.Add(this.txt_LavID);
            this.tabPage2.Controls.Add(this.txt_AtricleID);
            this.tabPage2.Controls.Add(this.txt_BuID);
            this.tabPage2.Controls.Add(this.cmb_RunDown);
            this.tabPage2.Controls.Add(this.cmb_RunUper);
            this.tabPage2.Controls.Add(this.dataGridViewDown);
            this.tabPage2.Controls.Add(this.dataGridViewUp);
            resources.ApplyResources(this.tabPage2, "tabPage2");
            this.tabPage2.Name = "tabPage2";
            this.tabPage2.UseVisualStyleBackColor = true;
            // 
            // lblLinia
            // 
            resources.ApplyResources(this.lblLinia, "lblLinia");
            this.lblLinia.Name = "lblLinia";
            // 
            // lblMold
            // 
            resources.ApplyResources(this.lblMold, "lblMold");
            this.lblMold.Name = "lblMold";
            // 
            // lblLav
            // 
            resources.ApplyResources(this.lblLav, "lblLav");
            this.lblLav.Name = "lblLav";
            // 
            // lblAritcle
            // 
            resources.ApplyResources(this.lblAritcle, "lblAritcle");
            this.lblAritcle.Name = "lblAritcle";
            // 
            // lblBu
            // 
            resources.ApplyResources(this.lblBu, "lblBu");
            this.lblBu.Name = "lblBu";
            // 
            // lblData
            // 
            resources.ApplyResources(this.lblData, "lblData");
            this.lblData.Name = "lblData";
            // 
            // dateTimePicker
            // 
            resources.ApplyResources(this.dateTimePicker, "dateTimePicker");
            this.dateTimePicker.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.dateTimePicker.Name = "dateTimePicker";
            // 
            // label8
            // 
            resources.ApplyResources(this.label8, "label8");
            this.label8.Name = "label8";
            // 
            // label7
            // 
            resources.ApplyResources(this.label7, "label7");
            this.label7.Name = "label7";
            // 
            // label6
            // 
            resources.ApplyResources(this.label6, "label6");
            this.label6.Name = "label6";
            // 
            // label5
            // 
            resources.ApplyResources(this.label5, "label5");
            this.label5.Name = "label5";
            // 
            // label4
            // 
            resources.ApplyResources(this.label4, "label4");
            this.label4.Name = "label4";
            // 
            // label3
            // 
            resources.ApplyResources(this.label3, "label3");
            this.label3.Name = "label3";
            // 
            // label2
            // 
            resources.ApplyResources(this.label2, "label2");
            this.label2.Name = "label2";
            // 
            // label1
            // 
            resources.ApplyResources(this.label1, "label1");
            this.label1.Name = "label1";
            // 
            // cmb_Manufatured
            // 
            resources.ApplyResources(this.cmb_Manufatured, "cmb_Manufatured");
            this.cmb_Manufatured.Name = "cmb_Manufatured";
            this.cmb_Manufatured.UseVisualStyleBackColor = true;
            this.cmb_Manufatured.Click += new System.EventHandler(this.cmb_Manufatured_Click);
            // 
            // lbl_Total
            // 
            resources.ApplyResources(this.lbl_Total, "lbl_Total");
            this.lbl_Total.Name = "lbl_Total";
            // 
            // comboBoxLinia
            // 
            this.comboBoxLinia.FormattingEnabled = true;
            resources.ApplyResources(this.comboBoxLinia, "comboBoxLinia");
            this.comboBoxLinia.Name = "comboBoxLinia";
            // 
            // txt_No45
            // 
            resources.ApplyResources(this.txt_No45, "txt_No45");
            this.txt_No45.Name = "txt_No45";
            this.txt_No45.TextChanged += new System.EventHandler(this.txt_No45_TextChanged);
            // 
            // txt_No46
            // 
            resources.ApplyResources(this.txt_No46, "txt_No46");
            this.txt_No46.Name = "txt_No46";
            this.txt_No46.TextChanged += new System.EventHandler(this.txt_No46_TextChanged);
            // 
            // txt_No44
            // 
            resources.ApplyResources(this.txt_No44, "txt_No44");
            this.txt_No44.Name = "txt_No44";
            this.txt_No44.TextChanged += new System.EventHandler(this.txt_No44_TextChanged);
            // 
            // txt_No43
            // 
            resources.ApplyResources(this.txt_No43, "txt_No43");
            this.txt_No43.Name = "txt_No43";
            this.txt_No43.TextChanged += new System.EventHandler(this.txt_No43_TextChanged);
            // 
            // txt_No41
            // 
            resources.ApplyResources(this.txt_No41, "txt_No41");
            this.txt_No41.Name = "txt_No41";
            this.txt_No41.TextChanged += new System.EventHandler(this.txt_No41_TextChanged);
            // 
            // txt_No42
            // 
            resources.ApplyResources(this.txt_No42, "txt_No42");
            this.txt_No42.Name = "txt_No42";
            this.txt_No42.TextChanged += new System.EventHandler(this.txt_No42_TextChanged);
            // 
            // txt_No40
            // 
            resources.ApplyResources(this.txt_No40, "txt_No40");
            this.txt_No40.Name = "txt_No40";
            this.txt_No40.TextChanged += new System.EventHandler(this.txt_No40_TextChanged);
            // 
            // txt_No39
            // 
            resources.ApplyResources(this.txt_No39, "txt_No39");
            this.txt_No39.Name = "txt_No39";
            this.txt_No39.TextChanged += new System.EventHandler(this.txt_No39_TextChanged);
            // 
            // txtFoudoID
            // 
            resources.ApplyResources(this.txtFoudoID, "txtFoudoID");
            this.txtFoudoID.Name = "txtFoudoID";
            // 
            // txt_LavID
            // 
            resources.ApplyResources(this.txt_LavID, "txt_LavID");
            this.txt_LavID.Name = "txt_LavID";
            this.txt_LavID.TextChanged += new System.EventHandler(this.txt_LavID_TextChanged);
            // 
            // txt_AtricleID
            // 
            resources.ApplyResources(this.txt_AtricleID, "txt_AtricleID");
            this.txt_AtricleID.Name = "txt_AtricleID";
            this.txt_AtricleID.TextChanged += new System.EventHandler(this.txt_AtricleID_TextChanged);
            // 
            // txt_BuID
            // 
            resources.ApplyResources(this.txt_BuID, "txt_BuID");
            this.txt_BuID.Name = "txt_BuID";
            // 
            // cmb_RunDown
            // 
            resources.ApplyResources(this.cmb_RunDown, "cmb_RunDown");
            this.cmb_RunDown.Name = "cmb_RunDown";
            this.cmb_RunDown.UseVisualStyleBackColor = true;
            this.cmb_RunDown.Click += new System.EventHandler(this.cmb_RunDown_Click);
            // 
            // cmb_RunUper
            // 
            resources.ApplyResources(this.cmb_RunUper, "cmb_RunUper");
            this.cmb_RunUper.Name = "cmb_RunUper";
            this.cmb_RunUper.UseVisualStyleBackColor = true;
            this.cmb_RunUper.Click += new System.EventHandler(this.cmb_RunUper_Click);
            // 
            // dataGridViewDown
            // 
            this.dataGridViewDown.AllowUserToAddRows = false;
            this.dataGridViewDown.AllowUserToDeleteRows = false;
            this.dataGridViewDown.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dataGridViewDown.ClipboardCopyMode = System.Windows.Forms.DataGridViewClipboardCopyMode.Disable;
            this.dataGridViewDown.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            resources.ApplyResources(this.dataGridViewDown, "dataGridViewDown");
            this.dataGridViewDown.Name = "dataGridViewDown";
            this.dataGridViewDown.ReadOnly = true;
            // 
            // dataGridViewUp
            // 
            this.dataGridViewUp.AllowUserToAddRows = false;
            this.dataGridViewUp.AllowUserToDeleteRows = false;
            this.dataGridViewUp.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dataGridViewUp.ClipboardCopyMode = System.Windows.Forms.DataGridViewClipboardCopyMode.Disable;
            this.dataGridViewUp.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            resources.ApplyResources(this.dataGridViewUp, "dataGridViewUp");
            this.dataGridViewUp.Name = "dataGridViewUp";
            this.dataGridViewUp.ReadOnly = true;
            // 
            // textBox1
            // 
            resources.ApplyResources(this.textBox1, "textBox1");
            this.textBox1.Name = "textBox1";
            // 
            // FormMySql
            // 
            resources.ApplyResources(this, "$this");
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.Controls.Add(this.tabControl1);
            this.Controls.Add(this.menuStrip1);
            this.MainMenuStrip = this.menuStrip1;
            this.Name = "FormMySql";
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewWorck)).EndInit();
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            this.tabControl1.ResumeLayout(false);
            this.tabPage1.ResumeLayout(false);
            this.tabPage2.ResumeLayout(false);
            this.tabPage2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewDown)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewUp)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.DataGridView dataGridViewWorck;
        private System.Windows.Forms.Button cmb_Save;
        private System.Windows.Forms.Button cmb_Delete;
        private System.Windows.Forms.Button cmb_Main_Exit;
        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.ToolStripMenuItem dataToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem workToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem manufactoringToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem laveToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem expeditionedToolStripMenuItem;
        private System.Windows.Forms.TabControl tabControl1;
        private System.Windows.Forms.TabPage tabPage1;
        private System.Windows.Forms.TabPage tabPage2;
        private System.Windows.Forms.DataGridView dataGridViewDown;
        private System.Windows.Forms.DataGridView dataGridViewUp;
        private System.Windows.Forms.Button cmb_RunUper;
        private System.Windows.Forms.Button cmb_RunDown;
        private System.Windows.Forms.TextBox txt_LavID;
        private System.Windows.Forms.TextBox txt_AtricleID;
        private System.Windows.Forms.TextBox txt_BuID;
        private System.Windows.Forms.TextBox txt_No41;
        private System.Windows.Forms.TextBox txt_No42;
        private System.Windows.Forms.TextBox txt_No40;
        private System.Windows.Forms.TextBox txt_No39;
        private System.Windows.Forms.TextBox txtFoudoID;
        private System.Windows.Forms.TextBox txt_No45;
        private System.Windows.Forms.TextBox txt_No46;
        private System.Windows.Forms.TextBox txt_No44;
        private System.Windows.Forms.TextBox txt_No43;
        private System.Windows.Forms.ComboBox comboBoxLinia;
        private System.Windows.Forms.Label lbl_Total;
        private System.Windows.Forms.Button cmb_Manufatured;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.DateTimePicker dateTimePicker;
        private System.Windows.Forms.Label lblLinia;
        private System.Windows.Forms.Label lblMold;
        private System.Windows.Forms.Label lblLav;
        private System.Windows.Forms.Label lblAritcle;
        private System.Windows.Forms.Label lblBu;
        private System.Windows.Forms.Label lblData;
        private System.Windows.Forms.TextBox textBox1;
    }
}

